# Changelog — Brand Identity Kit for Startups

All notable changes to this product are documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

This changelog is maintained in English regardless of product language mode (internal versioning document).

---

## [v1.0.0] — 2026-04-29 — **SHIPPED**

### Status

v1.0 final. All QA gates passed. Ready for Gumroad listing, landing-page deployment, and launch sequence.

### Added

**Root files**

- `00_README.md` — bilingual EN+ES product README with three-direction overview, folder structure, usage guide, compliance posture.
- `LICENSE-en.txt` / `LICENSE-es.txt` — single-startup license with multi-product / venture-studio upgrade pathway.

**Main deliverables — `/EN/` (12 files)**

- `01_brand-strategy-guide.docx` — flagship strategy doc, MOS Expert standard, ~24 pp.
- `02_visual-identity-system.docx` — full style-guide document covering all three directions, MOS Expert, ~28 pp.
- `03_brand-application-matrix.pdf` — single-page printable matrix.
- `04_voice-and-tone-guide.docx` — voice principles and copy library.
- `05_industry-adaptation-guide.docx` — 8 industry-specific notes.
- `06_pitch-deck-template.pptx` — 12-slide investor pitch deck.
- `07_brand-checklist-prelaunch.pdf` — 30-point checklist.
- `08_email-signature-pack.docx` — 6 signature variants + HTML.
- `09_social-bio-templates.md` — LinkedIn / X / Instagram bio templates.
- `10_landing-page-copy-skeleton.docx` — founder-led landing page skeleton.
- `11_brand-rollout-deck.pptx` — main `.pptx`, 14 slides, MOS Expert standard.
- `12_quick-reference-onepager.pdf` — single-page reference.

**Main deliverables — `/ES/` (12 files)**

- Parallel set, native Spanish, `tú` register.

**Bonus folder — `/Bonus/` (3 items)**

- `01_founder-voice-snippets-en.docx` + `01_founder-voice-snippets-es.docx`.
- `02_brand-glossary.pdf` — bilingual paired-column glossary (40 terms).
- `03_investor-pitch-brand-checklist-en.docx` + `.pdf` and `03_investor-pitch-brand-checklist-es.docx` + `.pdf`.

**Shared assets — `/shared/`**

- `brand-master.canva-link.txt` — duplicatable Canva share link with embedded usage instructions.
- `logos/` — light + dark logos for each of three directions, in `.svg`, `.png` (1×/2×/3×), `.pdf`, `.ico`.
- `icons/` — coordinated icon set per direction.
- `mockups/` — laptop, mobile, business-card, deck-cover, LinkedIn-cover mockups per direction.
- `color-tokens.json` — Tailwind / Style Dictionary compatible token file.
- `typography-specimen.pdf` — typography specimen sheets per direction.

### Three identity directions

- **Minimalist** — B2B SaaS, fintech, devtools. Anchor: Deep navy `#0F172A` + cyan `#06B6D4`. Inter Tight (display), Inter (body).
- **Bold** — Consumer, marketplace, AI/ML, climate. Anchor: Red `#DC2626` + cream `#FEF3C7`. Geist (display), Inter (body).
- **Editorial** — Mission-led, content-led, edtech, healthtech. Anchor: Forest `#064E3B` + cream `#F5F0E8`. Source Serif 4 (display), Source Sans 3 (body).

### Compliance snapshot

- Not legal advice. Trademark search and legal review are the buyer's responsibility.
- Third-party fonts shipped under SIL OFL 1.1 and Apache 2.0 — see `LICENSE-en.txt` §8 and `LICENSE-es.txt` §8.

### Known limitations

- v1.0 ships Canva as the master design format. Adobe (Illustrator) and Figma source files are v1.2 roadmap.
- Industry-vertical extension packs (SaaS, fintech, marketplace) are v1.1 roadmap.

---

## Versioning roadmap

- **v1.1** — vertical extension pack: SaaS, fintech, marketplace + 4 additional industry adaptation notes.
- **v1.2** — Figma + Illustrator source files for the three direction systems.
- **v2.0** — additional language modes (PT-BR for Brazilian founders) + investor-region variants (Asia, MENA).

---

© Mustapha Ukizuru — mustaphaukizuru.com
