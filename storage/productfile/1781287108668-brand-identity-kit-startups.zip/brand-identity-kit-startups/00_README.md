# Brand Identity Kit for Startups

**Version:** v1.0 — April 2026
**Owner:** Mustapha Ukizuru — [mustaphaukizuru.com](https://mustaphaukizuru.com)
**Contact:** hello@mustaphaukizuru.com
**License:** Single-startup use. See `LICENSE-en.txt` and `LICENSE-es.txt`.

---

## EN — What's inside

A bilingual brand identity system for the LATAM founder pitching US investors. Three identity directions in one Canva master, two `.pptx` decks (pitch + rollout), full style guides in `.docx`, logo files in light/dark mode, mockup pack, and a one-page brand-application matrix that lands deck, email, social, and screenshot mockups on day one.

### Folder structure

```
/01_product/
├── 00_README.md                     ← this file (bilingual)
├── LICENSE-en.txt
├── LICENSE-es.txt
├── CHANGELOG.md
├── EN/                              ← 12 deliverables in English
├── ES/                              ← 12 deliverables in Spanish
├── shared/                          ← Canva master, logos, icons, mockups, color tokens
└── Bonus/                           ← 3 supporting items (snippets, glossary, pitch-asset checklist)
```

### How to use

1. **Read the Brand Strategy Guide first** (`EN/01_brand-strategy-guide.docx`). It frames every other deliverable.
2. **Open the Canva master** via the link in `shared/brand-master.canva-link.txt`. Duplicate it to your own Canva workspace.
3. **Pick one of the three directions** (Minimalist, Bold, or Editorial). A/B with your co-founder using the criteria in §4 of the Strategy Guide.
4. **Customize logo and colors** — replace placeholder name with yours; swap the accent token if needed (see `shared/color-tokens.json`).
5. **Apply across the matrix** — work down `EN/03_brand-application-matrix.pdf` to deploy the brand on deck, email signature, LinkedIn cover, social avatars, business card, favicon, and slide template.
6. **Run the prelaunch checklist** (`EN/07_brand-checklist-prelaunch.pdf`) before your next investor meeting.

### Editing notes

- All `.docx` files use Word styles — adjust through `Design → Themes` and the Styles gallery, never through manual formatting.
- All `.pptx` decks use customized Slide Masters — `View → Slide Master` to update brand globally.
- Logo `.svg` files are vector — open in Figma, Illustrator, or Affinity Designer for further customization.
- The Canva master is your editable working copy. Keep it private; do not redistribute (see license).

### Three identity directions at a glance

| Direction | Use when | Color anchor | Display font | Body font |
|---|---|---|---|---|
| **Minimalist** | B2B SaaS, fintech, devtools — credibility-first | Deep navy `#0F172A` + cyan accent `#06B6D4` | Inter Tight (display) | Inter (body) |
| **Bold** | Consumer, marketplace, AI/ML, climate — energy-first | Bold red `#DC2626` + warm cream `#FEF3C7` | Geist (display) | Inter (body) |
| **Editorial** | Mission-led, content-led, edtech, healthtech — authority-first | Forest green `#064E3B` + cream `#F5F0E8` | Source Serif 4 (display) | Source Sans 3 (body) |

### Compliance & disclaimers

- **Not legal advice.** The kit does not include trademark search or legal review. Run a trademark search before public launch.
- **License terms** prohibit redistribution of the Canva master or any source files. The license is single-startup — covers one company / one brand / one team.
- **Multi-product license** available for accelerators / venture studios deploying the kit across portfolio companies — contact hello@mustaphaukizuru.com.

### Support

Questions, errata, or feature requests: **hello@mustaphaukizuru.com**

---

## ES — Qué incluye este paquete

Un sistema bilingüe de identidad de marca para el fundador LATAM que está levantando con inversionistas de EE. UU. Tres direcciones de identidad en un único Canva master, dos `.pptx` (pitch + rollout interno), guías completas en `.docx`, logos en modo claro/oscuro, pack de mockups y una matriz de aplicación de marca de una página que lleva deck, correo, redes y mockups de producto a piso desde el día uno.

### Estructura de carpetas

```
/01_product/
├── 00_README.md                     ← este archivo (bilingüe)
├── LICENSE-en.txt
├── LICENSE-es.txt
├── CHANGELOG.md
├── EN/                              ← 12 entregables en inglés
├── ES/                              ← 12 entregables en español
├── shared/                          ← Canva master, logos, íconos, mockups, tokens
└── Bonus/                           ← 3 elementos complementarios
```

### Cómo utilizarlo

1. **Lee primero la Guía de Estrategia de Marca** (`ES/01_guia-de-estrategia-de-marca.docx`). Es el marco de los demás entregables.
2. **Abre el Canva master** con el link en `shared/brand-master.canva-link.txt`. Duplícalo a tu workspace de Canva.
3. **Elige una de las tres direcciones** (Minimalista, Bold o Editorial). Haz un A/B con tu cofundador usando los criterios de la §4 de la Guía.
4. **Personaliza el logotipo y los colores** — sustituye el nombre placeholder por el tuyo; ajusta el token de acento si lo necesitas (ver `shared/color-tokens.json`).
5. **Aplica en toda la matriz** — usa `ES/03_matriz-de-aplicacion-de-marca.pdf` para desplegar la marca en deck, firma de correo, portada de LinkedIn, avatares de redes, tarjeta y favicon.
6. **Ejecuta el checklist previo al lanzamiento** (`ES/07_checklist-prelanzamiento-marca.pdf`) antes de tu siguiente reunión con inversionistas.

### Notas para editar

- Todos los archivos `.docx` aplican estilos de Word — modifica desde `Diseño → Temas` y la galería de estilos, no con formato manual.
- Las `.pptx` usan Patrones de Diapositivas personalizados — `Vista → Patrón de Diapositivas` para cambios globales.
- Los logos `.svg` son vectoriales — ábrelos en Figma, Illustrator o Affinity Designer para personalización avanzada.
- El Canva master es tu archivo de trabajo. Mantenlo privado; no lo redistribuyas (ver licencia).

### Las tres direcciones en una mirada

| Dirección | Cuándo usarla | Ancla de color | Tipografía display | Tipografía body |
|---|---|---|---|---|
| **Minimalista** | B2B SaaS, fintech, devtools — credibilidad primero | Azul profundo `#0F172A` + cian `#06B6D4` | Inter Tight | Inter |
| **Bold** | Consumo, marketplace, AI/ML, clima — energía primero | Rojo `#DC2626` + crema `#FEF3C7` | Geist | Inter |
| **Editorial** | Mision-led, content-led, edtech, healthtech — autoridad primero | Verde bosque `#064E3B` + crema `#F5F0E8` | Source Serif 4 | Source Sans 3 |

### Cumplimiento y avisos

- **No es asesoría legal.** El kit no incluye búsqueda de marca registrada ni revisión legal. Realiza la búsqueda antes del lanzamiento público.
- **Términos de licencia** prohíben la redistribución del Canva master o de los archivos fuente. La licencia es para una sola startup — cubre una empresa / una marca / un equipo.
- **Licencia multi-producto** disponible para aceleradoras / venture studios que desplieguen el kit en su portafolio — escribe a hello@mustaphaukizuru.com.

### Soporte

Preguntas, erratas o solicitudes de funcionalidad: **hello@mustaphaukizuru.com**

---

© Mustapha Ukizuru — mustaphaukizuru.com
