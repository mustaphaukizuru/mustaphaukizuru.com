# Social Bio Templates — Brand Identity Kit for Startups (EN)

**Version:** v1.0 — April 2026
**Owner:** Mustapha Ukizuru — mustaphaukizuru.com

Paste-ready bio templates for LinkedIn, Twitter/X, and Instagram. Replace bracketed fields with your specifics. Each template carries a character count and a use case.

---

## LinkedIn

### LinkedIn Headline (≤ 220 characters)

**A. Operator format**
```
Founder, [Startup] · We help [BUYER] [DESIRED OUTCOME] · [METRIC] · [LATAM city] → global · Hiring [ROLE]
```
*Use when:* you are actively recruiting and want to surface that without a separate post.

**B. Story format**
```
Building [Startup] — [BUYER] go from [BEFORE] to [AFTER] in [TIMEFRAME] · ex-[PRIOR-COMPANY] · [LATAM city]
```
*Use when:* prior credibility (job history) is your strongest signal to investors and customers.

**C. Direct format**
```
Founder & CEO, [Startup] · [WHAT WE DO IN ONE LINE]
```
*Use when:* the company name is the strongest signal and you want to keep the headline simple.

### LinkedIn About (paste-ready, ~600 characters)

```
I'm building [Startup] because [BUYER] currently [PAINFUL CURRENT STATE], and the existing solutions
([INCUMBENT 1], [INCUMBENT 2]) miss [SPECIFIC GAP].

[Startup] takes [BUYER] from [BEFORE] to [AFTER] in [TIMEFRAME] using [SHORT MECHANISM]. We've gone from
[BASELINE METRIC] to [CURRENT METRIC] in [TIMEFRAME], and we're backed by [INVESTOR / NAMED SUPPORTER].

Before this, I [SHORT PRIOR-WORK SENTENCE — engineer, designer, ex-operator at X].

Currently raising [SEED / SERIES A] · Hiring [ROLE] · LATAM-based, serving [GEOGRAPHY].

DM me if you [SPECIFIC ASK — invest, customer, hire].
```

### LinkedIn Banner CTA (the line at the bottom of the cover image)

```
[Startup] · [TAGLINE ≤ 8 words] · [URL]
```

---

## Twitter / X

### Bio (≤ 160 characters)

**A. Operator format**
```
Founder, [Startup] · [WHAT WE DO IN ONE LINE] · [METRIC] · [LATAM city] · DM open
```

**B. Founder-voice format**
```
Building [Startup] — [BUYER] go from [BEFORE] to [AFTER] · prev [PRIOR COMPANY] · [LATAM city] · 🇲🇽 → 🌎
```
*Note:* emoji discipline — at most 2 per bio. The 🇲🇽 → 🌎 pattern signals geography in 4 characters.

**C. Direct format**
```
[Startup] · [TAGLINE] · [URL]
```

### Pinned tweet patterns (5 templates)

1. **The launch tweet:**
   ```
   We built [Startup] because [BUYER] still [PAINFUL THING].
   We get them to [DESIRED OUTCOME] in [TIMEFRAME].
   [Metric in numbers].
   [URL]
   ```

2. **The build-in-public update:**
   ```
   Six months ago: [BASELINE]
   Today: [CURRENT METRIC]
   What changed: [ONE-SENTENCE LEARNING]
   What's next: [ONE-SENTENCE NEXT BET]
   ```

3. **The hiring tweet:**
   ```
   Hiring [ROLE] at [Startup].
   What you'll work on: [ONE LINE]
   What we offer: [ONE LINE — equity / remote / pay range]
   [URL]
   ```

4. **The investor signal:**
   ```
   Raising [ROUND] for [Startup].
   We help [BUYER] [DESIRED OUTCOME].
   [Single hardest metric — MRR / users / retention].
   DM open.
   ```

5. **The customer testimonial:**
   ```
   "[CUSTOMER QUOTE — short]"
   — [CUSTOMER NAME], [CUSTOMER ROLE]
   [Startup] · [URL]
   ```

---

## Instagram

### Bio (≤ 150 characters)

**A. Operator format**
```
[Startup]
[WHAT WE DO IN ONE LINE]
[CITY] · [WEBSITE]
↓ Demo
```

**B. Founder-voice format**
```
Founder, [Startup]
Building [WHAT] for [BUYER]
[CITY] 🇲🇽
↓ Latest
```

### Link-in-bio pattern

Use a single page (Beacons, Linktree, or self-hosted at /links). Keep it short:

```
[STARTUP LOGO]
[Tagline ≤ 8 words]

→ Get a demo
→ Read the latest post
→ See pricing
→ DM founder

[mustaphaukizuru.com] · © [Startup] 2026
```

---

## Universal rules for all three platforms

- **No "founder & dreamer."** Founder is a job; dreamer is not. Pick verbs that do work.
- **Avoid "🚀 disrupting the X industry."** Earned credibility beats borrowed momentum.
- **Use ONE call-to-action per surface.** A bio with three CTAs has zero CTAs.
- **Keep the LATAM signal honest.** If you operate from Mexico City, say so. Founders who hide their geography lose the LATAM-investor segment that wants to back you specifically because of it.
- **Update quarterly, not weekly.** Stable bios build pattern recognition with the same buyers who see you across platforms.

---

## Bio coherence checklist (run before publishing)

- [ ] Same wordmark / handle across LinkedIn, Twitter/X, Instagram (or as close as namespace conflicts allow).
- [ ] Same one-line description (rephrased per platform character limits, not contradictory).
- [ ] Same CTA destination (link-in-bio, LinkedIn featured, X pinned tweet — all point to the same thing).
- [ ] Same brand color in the cover image / banner across LinkedIn and Twitter/X.
- [ ] Same founder photo crop on LinkedIn, Twitter/X, Instagram (helps recognition for investors who check three platforms before replying).

---

© Mustapha Ukizuru — mustaphaukizuru.com
