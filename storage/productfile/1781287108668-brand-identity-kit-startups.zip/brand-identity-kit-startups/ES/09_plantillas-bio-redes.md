# Plantillas de Bio para Redes — Kit de Identidad de Marca para Startups (ES)

**Versión:** v1.0 — abril de 2026
**Titular:** Mustapha Ukizuru — mustaphaukizuru.com

Plantillas listas para pegar en LinkedIn, Twitter/X e Instagram. Sustituye los campos entre corchetes por tus específicos. Cada plantilla incluye conteo de caracteres y caso de uso.

---

## LinkedIn

### Encabezado de LinkedIn (≤ 220 caracteres)

**A. Formato operador**
```
Fundador, [Startup] · Ayudamos a [COMPRADOR] a [RESULTADO DESEADO] · [MÉTRICA] · [ciudad LATAM] → global · Contratando [ROL]
```
*Cuándo:* estás contratando activamente y quieres surfacearlo sin un post separado.

**B. Formato historia**
```
Construyendo [Startup] — [COMPRADOR] pasa de [ANTES] a [DESPUÉS] en [PLAZO] · ex-[EMPRESA PREVIA] · [ciudad LATAM]
```
*Cuándo:* tu credibilidad previa (historial laboral) es tu señal más fuerte para inversionistas y clientes.

**C. Formato directo**
```
Fundador y CEO, [Startup] · [LO QUE HACEMOS EN UNA LÍNEA]
```
*Cuándo:* el nombre de la empresa es la señal más fuerte y quieres mantener el encabezado simple.

### LinkedIn Acerca de (listo para pegar, ~600 caracteres)

```
Estoy construyendo [Startup] porque [COMPRADOR] actualmente [ESTADO ACTUAL DOLOROSO], y las soluciones existentes
([INCUMBENTE 1], [INCUMBENTE 2]) no resuelven [BRECHA ESPECÍFICA].

[Startup] lleva a [COMPRADOR] de [ANTES] a [DESPUÉS] en [PLAZO] usando [MECANISMO CORTO]. Pasamos de [MÉTRICA BASE] a
[MÉTRICA ACTUAL] en [PLAZO], y nos respalda [INVERSIONISTA / NOMBRE].

Antes de esto, [ORACIÓN CORTA SOBRE TRABAJO PREVIO — ingeniero, diseñador, ex-operador en X].

Levantando [PRE-SEED / SEED / SERIE A] · Contratando [ROL] · Basado en LATAM, atendiendo [GEOGRAFÍA].

Si quieres [PEDIDO ESPECÍFICO — invertir, ser cliente, sumarte], escríbeme.
```

### LinkedIn Banner CTA (línea inferior de la portada)

```
[Startup] · [TAGLINE ≤ 8 palabras] · [URL]
```

---

## Twitter / X

### Bio (≤ 160 caracteres)

**A. Formato operador**
```
Fundador, [Startup] · [LO QUE HACEMOS EN UNA LÍNEA] · [MÉTRICA] · [ciudad LATAM] · DM abierto
```

**B. Voz de fundador**
```
Construyendo [Startup] — [COMPRADOR] pasa de [ANTES] a [DESPUÉS] · prev [EMPRESA PREVIA] · [ciudad LATAM] · 🇲🇽 → 🌎
```
*Nota:* disciplina de emoji — máximo 2 por bio. El patrón 🇲🇽 → 🌎 señala geografía en 4 caracteres.

**C. Formato directo**
```
[Startup] · [TAGLINE] · [URL]
```

### Patrones de tweet fijado (5 plantillas)

1. **Tweet de lanzamiento:**
   ```
   Construimos [Startup] porque [COMPRADOR] todavía [COSA DOLOROSA].
   Los llevamos a [RESULTADO DESEADO] en [PLAZO].
   [Métrica en números].
   [URL]
   ```

2. **Update build-in-public:**
   ```
   Hace seis meses: [BASE]
   Hoy: [MÉTRICA ACTUAL]
   Qué cambió: [APRENDIZAJE EN UNA ORACIÓN]
   Qué sigue: [SIGUIENTE APUESTA EN UNA ORACIÓN]
   ```

3. **Tweet de contratación:**
   ```
   Contratando [ROL] en [Startup].
   En qué trabajarás: [UNA LÍNEA]
   Qué ofrecemos: [UNA LÍNEA — equity / remoto / rango salarial]
   [URL]
   ```

4. **Señal de levantamiento:**
   ```
   Levantando [RONDA] para [Startup].
   Ayudamos a [COMPRADOR] a [RESULTADO DESEADO].
   [Métrica más dura — MRR / usuarios / retención].
   DM abierto.
   ```

5. **Testimonio de cliente:**
   ```
   "[CITA DEL CLIENTE — corta]"
   — [NOMBRE], [ROL]
   [Startup] · [URL]
   ```

---

## Instagram

### Bio (≤ 150 caracteres)

**A. Formato operador**
```
[Startup]
[LO QUE HACEMOS EN UNA LÍNEA]
[Ciudad] · [WEBSITE]
↓ Demo
```

**B. Voz de fundador**
```
Fundador, [Startup]
Construyendo [QUÉ] para [COMPRADOR]
[Ciudad] 🇲🇽
↓ Lo último
```

### Patrón link-in-bio

Usa una sola página (Beacons, Linktree o self-hosted en /links). Mantenla corta:

```
[LOGO STARTUP]
[Tagline ≤ 8 palabras]

→ Solicitar demo
→ Leer lo último
→ Ver precios
→ DM al fundador

[mustaphaukizuru.com] · © [Startup] 2026
```

---

## Reglas universales para las tres plataformas

- **Sin "fundador y soñador."** Fundador es un trabajo; soñador no. Elige verbos que hagan trabajo.
- **Evita "🚀 disrupting el sector X."** La credibilidad ganada le gana al momentum prestado.
- **Usa UN llamado a la acción por superficie.** Una bio con tres CTAs tiene cero CTAs.
- **Mantén la señal LATAM honesta.** Si operas desde CDMX, dilo. Los fundadores que ocultan su geografía pierden el segmento de inversionistas LATAM que quiere apoyarte específicamente por eso.
- **Actualiza trimestralmente, no semanalmente.** Las bios estables construyen reconocimiento de patrón con los mismos compradores que te ven en varias plataformas.

---

## Checklist de coherencia entre bios (corre antes de publicar)

- [ ] Mismo wordmark / handle en LinkedIn, Twitter/X, Instagram (o lo más cercano que permitan los namespaces).
- [ ] Misma descripción en una línea (reformulada por límites de caracteres, no contradictoria).
- [ ] Mismo destino del CTA (link-in-bio, LinkedIn featured, X tweet fijado — todos al mismo lugar).
- [ ] Mismo color de marca en la portada / banner de LinkedIn y Twitter/X.
- [ ] Mismo recorte de foto del fundador en LinkedIn, Twitter/X, Instagram (ayuda al reconocimiento de inversionistas que revisan tres plataformas antes de responder).

---

© Mustapha Ukizuru — mustaphaukizuru.com
